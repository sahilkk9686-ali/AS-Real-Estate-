AS REAL ESTATE CLOUD V1

This version uses Firebase Authentication, Firestore and Cloud Storage.

SETUP:
1. Create a Firebase project.
2. Add a Web App and copy its config into firebase-config.js.
3. Authentication -> Sign-in method -> enable Anonymous.
4. Firestore Database -> Create database.
5. Storage -> Get started.
6. Paste the Firestore and Storage rules from FIREBASE_RULES.txt.
7. Upload all files to the root of your GitHub repository (do NOT upload only the ZIP).
8. Enable GitHub Pages from Settings -> Pages -> Deploy from branch -> main -> /(root).

IMPORTANT:
- Videos/documents are stored in Firebase Cloud Storage.
- Property details are stored in Firestore.
- Anyone with a property link can read the public property record and open its media.
- Keep Firebase client config in the site; it is normal for Firebase Web API keys to be visible. Security comes from Firebase rules.
