import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, orderBy } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";
import { getStorage, ref, uploadBytesResumable, getDownloadURL } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const app=initializeApp(firebaseConfig), auth=getAuth(app), db=getFirestore(app), storage=getStorage(app);
let all=[];
const $=id=>document.getElementById(id);
$("addBtn").onclick=()=>$("formCard").classList.toggle("hidden");
$("search").oninput=render;
window.closePlayer=()=>{$("videoPlayer").pause();$("videoPlayer").src="";$("player").classList.add("hidden")};

function msg(t){$("status").textContent=t}
async function init(){
 try{await signInAnonymously(auth); await load(); msg("Cloud connected ✓")}
 catch(e){console.error(e);msg("Firebase setup pending: add your Firebase configuration and enable Anonymous sign-in.")}
}
async function load(){
 const snap=await getDocs(query(collection(db,"properties"),orderBy("createdAt","desc")));
 all=snap.docs.map(d=>({id:d.id,...d.data()})); render();
}
function render(){
 const s=$("search").value.toLowerCase();
 const rows=all.filter(x=>(x.title+" "+x.location+" "+x.description).toLowerCase().includes(s));
 $("list").innerHTML=rows.map(x=>`
 <article class="property"><h3>${esc(x.title||"Property")}</h3>
 <div class="muted">${esc(x.location||"")} ${x.acres?`• ${esc(String(x.acres))} acres`:""} ${x.price?`• ${esc(x.price)}`:""}</div>
 <p>${esc(x.description||"")}</p>
 <div class="actions">
 ${x.videoUrl?`<button onclick="playVideo('${x.videoUrl}')">▶ Open Video</button>`:""}
 ${x.docUrl?`<button onclick="window.open('${x.docUrl}','_blank')">📄 Open Document</button>`:""}
 ${x.videoUrl||x.docUrl?`<button onclick="shareProperty('${location.origin}${location.pathname}?property=${x.id}')">↗ Share</button>`:""}
 </div></article>`).join("") || '<div class="property">No properties yet.</div>';
}
window.playVideo=url=>{$("videoPlayer").src=url;$("player").classList.remove("hidden");$("videoPlayer").play().catch(()=>{})};
window.shareProperty=async url=>{try{await navigator.share({title:"AS Real Estate",url})}catch{await navigator.clipboard.writeText(url);alert("Link copied")}};
function esc(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

async function upload(file,path,label){
 if(!file)return null;
 return new Promise((resolve,reject)=>{
  const task=uploadBytesResumable(ref(storage,path),file);
  task.on("state_changed",s=>{$("progress").textContent=`Uploading ${label}: ${Math.round(s.bytesTransferred/s.totalBytes*100)}%`},reject,async()=>resolve(await getDownloadURL(task.snapshot.ref)));
 });
}
$("saveBtn").onclick=async()=>{
 try{
  $("saveBtn").disabled=true;
  const uid=auth.currentUser.uid, id=crypto.randomUUID();
  const video=$("video").files[0], doc=$("doc").files[0];
  const base=`properties/${uid}/${id}`;
  const videoUrl=await upload(video,`${base}/video-${video?.name||"file"}`,"video");
  const docUrl=await upload(doc,`${base}/document-${doc?.name||"file"}`,"document");
  await addDoc(collection(db,"properties"),{title:$("title").value,location:$("location").value,acres:$("acres").value,price:$("price").value,description:$("description").value,videoUrl,docUrl,createdAt:Date.now(),ownerUid:uid});
  $("progress").textContent="Saved ✓"; ["title","location","acres","price","description"].forEach(id=>$(id).value="");$("video").value="";$("doc").value="";
  await load();
 }catch(e){console.error(e);alert(e.message||"Upload failed")}finally{$("saveBtn").disabled=false}
};
init();