AS REAL ESTATE — V2

This is a Progressive Web App (PWA).
Main fixes:
- Videos are stored in the browser's IndexedDB instead of navigating to blob:null URLs.
- Video opens inside the app's own player.
- Documents open inside an in-app viewer.
- Property data remains on the device/browser.
- PWA manifest + service worker are included for Add to Home Screen.

IMPORTANT:
For the real "Add to Home Screen" PWA experience, these files must be hosted on HTTPS
(such as a static hosting service). Opening index.html directly as a local file may not
show the install button.

Recommended use:
1. Host the folder on an HTTPS static site.
2. Open the site in Chrome on Android.
3. Tap "Add AS Real Estate to Home Screen" when shown, or Chrome menu > Add to Home screen.
4. Upload videos from inside the app.
5. Tap Open Video — it plays inside the app; it does not navigate to blob:null.

Note: Browser storage is device/browser specific. Clearing site data can remove locally stored
videos and documents. This version does not upload files to a cloud server.
